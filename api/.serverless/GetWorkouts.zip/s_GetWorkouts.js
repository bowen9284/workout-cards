
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'bowen9284',
  applicationName: 'workout-deck',
  appUid: 'pqVYw7rmv39sLG0vB8',
  orgUid: 'LTLDW09NG5khk3FNtY',
  deploymentUid: '43acddf7-c117-4b13-85a1-7861dda4a4ba',
  serviceName: 'workout-deck',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.8',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'workout-deck-dev-GetWorkouts', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/getWorkouts.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}